import React from "react";
import "./contact.css";
import { BsMessenger } from "react-icons/bs";

const Contact = () => {
  return (
    <section className="section" id="contact">
      <div className="contact container">
        <div className="contact-top-info">
          <h2 className="contact-title">CONTACT</h2>
          <div className="line-bottom"></div>
          <p className="contact-description">
            Feel free to Contact me. I will get back to you as soon as possible
          </p>
        </div>

        <div className="contact-content">
          <h3 className="contact-content-title">Talk to me</h3>
          <div className="contact-info">
            <div className="contact-card">
              <i className="uil uil-envelope-minus"></i>
              <h3 className="contact-card-title">Email</h3>
              <span className="contact-card-data">
                shendritcocaj@hotmail.com
              </span>
              <a
                href="mailto:shendritcocaj@hotmail.com"
                target="_blank"
                className="contact-button"
              >
                Write me{" "}
                <i className="uil uil-arrow-right contact-button-icon"></i>
              </a>
            </div>
            <div className="contact-card">
              <i className="uil uil-whatsapp"></i>
              <h3 className="contact-card-title">Whatsapp</h3>
              <span className="contact-card-data"> 049-377-922</span>
              <a
                href="https://wa.me/+38349377922"
                target="_blank"
                className="contact-button"
              >
                Write me{" "}
                <i className="uil uil-arrow-right contact-button-icon"></i>
              </a>
            </div>
            <div className="contact-card">
              <BsMessenger className="contact-messenger" />
              <h3 className="contact-card-title mesenger">Messenger</h3>
              <span className="contact-card-data">Shendrit Cocaj</span>
              <a
                href="https://m.me/shendritt"
                target="_blank"
                className="contact-button"
              >
                Write me{" "}
                <i className="uil uil-arrow-right contact-button-icon"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
