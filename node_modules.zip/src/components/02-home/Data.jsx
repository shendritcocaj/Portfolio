import React from "react";

import { GiHand } from "react-icons/gi";
const Data = () => {
  return (
    <div className="home-data">
      <h1 className="home-title">
        Shëndrit Çoçaj
        <GiHand className="wave-hand" />
      </h1>
      <h3 className="home-subtitle">Frontend Web Developer </h3>
      <p className="home-description">
        A Frontend Web Developer based in Prishtina-Kosovo, and I'm very
        passionate and dedicated to my work...
      </p>
      <a href="#contact" className="home-button">
        Say Hello <i className="uil uil-message "></i>
      </a>
    </div>
  );
};

export default Data;
