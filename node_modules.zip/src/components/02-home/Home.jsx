import React from "react";
import "./home.css";
import Social from "./Social";
import Data from "./Data";

const Home = () => {
  return (
    <section className="home section" id="home">
      <div className="home-container container ">
        <div className="home-content">
          <div className="home-top-query">
            <Social />
            <img className="home-img" src="" alt="" />
          </div>{" "}
          <Data />
        </div>
        <p className="home-scrollDown-name">
          Scroll Down <i className="uil uil-arrow-down"></i>
        </p>
        <div className="home-scrollDown"></div>
      </div>
      <div className="overlay"></div>
    </section>
  );
};

export default Home;
